/**
 * Teacher: Ms. Krasteva
 * Assignment: This program creates a random sentence with words from a word bank made with ArrayLists
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/07/2023
 */

/* imports the ArrayList class */
import java.util.ArrayList;

/**
 * the CrazySentences class
 */
public class CrazySentences {

  /* String variable to alter using random generator */
  private String sentence = "";

  /**
   * word storage for the random sentence; words are called to be stored in
   * ArrayLists based on their type (e.g. verb, noun, etc.)
   */
  ArrayList<String> article = new ArrayList<String>();
  ArrayList<String> capArticle = new ArrayList<String>();
  ArrayList<String> noun = new ArrayList<String>();
  ArrayList<String> verb = new ArrayList<String>();
  ArrayList<String> preposition = new ArrayList<String>();
  ArrayList<String> adverb = new ArrayList<String>();
  ArrayList<String> adjective = new ArrayList<String>();

  /* CrazySentences class constructor */
  public CrazySentences() {
  }

  /**
   * fillArray method
   * calls the fill methods to fill the ArrayLists with the words from the
   * wordbank
   */
  public void fillArray() {
    fillArticle();
    fillCapArticle();
    fillNoun();
    fillAdverb();
    fillAdject();
    fillPrep();
    fillVerb();
  }

  /**
   * fillCapArticle method
   * wordbank containing the capitalized articles (to be used at the beginning of
   * each sentence)
   */
  public void fillCapArticle() {
    capArticle.add("An");
    capArticle.add("The");
    capArticle.add("A");
  }

  /**
   * fillArticle method
   * wordbank containing the non-capitalized articles
   */
  public void fillArticle() {
    article.add("an");
    article.add("the");
    article.add("a");
  }

  /**
   * fillNoun method
   * wordbank containing the nouns
   */
  public void fillNoun() {
    noun.add("cat");
    noun.add("egg");
    noun.add("boy");
    noun.add("girl");
    noun.add("car");
    noun.add("bridge");
    noun.add("snail");
    noun.add("orphan");
    noun.add("banana");
    noun.add("elf");
  }

  /**
   * fillVer method
   * wordbank containing the verbs
   */
  public void fillVerb() {
    verb.add("jumps");
    verb.add("dances");
    verb.add("flies");
    verb.add("slides");
    verb.add("walks");
    verb.add("returns");
    verb.add("climbs");
    verb.add("shakes");
    verb.add("runs");
    verb.add("tiptoes");
  }

  /**
   * fillPrep method
   * wordbank containing the prepositions
   */
  public void fillPrep() {
    preposition.add("at");
    preposition.add("by");
    preposition.add("for");
    preposition.add("under");
    preposition.add("in");
    preposition.add("off");
    preposition.add("on");
    preposition.add("over");
    preposition.add("to");
    preposition.add("with");
  }

  /**
   * fillAdverb method
   * wordbank containing the adverbs
   */
  public void fillAdverb() {
    adverb.add("unnecessarily");
    adverb.add("happily");
    adverb.add("briefly");
    adverb.add("merrily");
    adverb.add("boldly");
    adverb.add("quickly");
    adverb.add("impishly");
    adverb.add("funnily");
    adverb.add("angrily");
    adverb.add("proudly");
  }

  /**
   * fillAdject method
   * wordbank containing the adjectives
   */
  public void fillAdject() {
    adjective.add("beautiful");
    adjective.add("merciful");
    adjective.add("grown");
    adjective.add("comedic");
    adjective.add("angry");
    adjective.add("ecstatic");
    adjective.add("jealous");
    adjective.add("big");
    adjective.add("cacophonous");
    adjective.add("idiosyncratic");
  }

  /**
   * makeSentence method
   * assembles sentence word by word using generator to access ArrayLists
   */
  public void makeSentence() {
    String noun1 = noun.get((int) (Math.random() * noun.size()));
    String adverb1 = adverb.get((int) (Math.random() * adverb.size()));
    String adjective1 = adjective.get((int) (Math.random() * adjective.size()));
    if (noun1.charAt(0) == ('a') || noun1.charAt(0) == ('e') || noun1.charAt(0) == ('i') || noun1.charAt(0) == ('o')
        || noun1.charAt(0) == ('u')) {
      sentence += capArticle.get((int) (Math.random() * (capArticle.size() - 1)));
    } else
      sentence += capArticle.get((int) (Math.random() * (capArticle.size() - 1)) + 1);
    sentence += " ";
    sentence += noun1;
    sentence += " ";
    sentence += verb.get((int) (Math.random() * verb.size()));
    sentence += " ";
    sentence += preposition.get((int) (Math.random() * preposition.size()));
    sentence += " ";
    int choose = ((int) (Math.random() * 2));
    if (choose == 0) {
      if (adverb1.charAt(0) == ('a') || adverb1.charAt(0) == ('e') || adverb1.charAt(0) == ('i')
          || adverb1.charAt(0) == ('o') || adverb1.charAt(0) == ('u')) {
        sentence += article.get((int) (Math.random() * (article.size() - 1)));
      } else
        sentence += article.get((int) (Math.random() * (article.size() - 1)) + 1);
      sentence += " ";
      sentence += adverb1;
    } else {
      if (adjective1.charAt(0) == ('a') || adjective1.charAt(0) == ('e') || adjective1.charAt(0) == ('i')
          || adjective1.charAt(0) == ('o') || adjective1.charAt(0) == ('u')) {
        sentence += article.get((int) (Math.random() * (article.size() - 1)));
      } else
        sentence += article.get((int) (Math.random() * (article.size() - 1)) + 1);
      sentence += " ";
      sentence += adjective1;
    }
    sentence += " ";
    sentence += noun.get((int) (Math.random() * noun.size()));
    sentence += ".";
  }

  /**
   * printSentence method
   * calls makeSentence to generate a new sentence and prints it
   */
  public void printSentence() {
    makeSentence();
    System.out.println(sentence);
  }

}