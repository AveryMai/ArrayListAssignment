/**
 * Teacher: Ms. Krasteva
 * Assignment: This program calls the methods from the Bridge class to the main
 * class
 * 
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/07/2023
 */

public class BridgeDriver extends Bridge {

    /**
     * Main method of the assignment
     * Calls methods from Bridge class
     */
    public static void main(String[] args) {
        Bridge b1 = new Bridge();
        b1.shuffle();
        b1.deal();
        b1.printPlayer(p1, 1);
        b1.printPlayer(p2, 2);
        b1.printPlayer(p3, 3);
        b1.printPlayer(p4, 4);
        b1.declareWinner();
    }
}