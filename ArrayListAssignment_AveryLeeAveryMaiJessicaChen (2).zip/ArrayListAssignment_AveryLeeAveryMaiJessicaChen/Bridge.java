/**
* Teacher: Ms. Krasteva
* Assignment: This program shuffles and deals a game of bridge to 4 players, and prints out their scores.
* @author Avery Mai, Avery Lee, Jessica Chen
* @version 03/07/2023
*/

/* imports the ArrayList class */
import java.util.ArrayList;
import java.util.*;
import java.util.Arrays;

/**
 * the CrazySentences class
 */
public class Bridge {

    /* String variables for player decks */
    static public String p1 = "";
    static public String p2 = "";
    static public String p3 = "";
    static public String p4 = "";
    static public int winner;
    static public int winnerPoints = 0;
    /* int variable for points count */
    private int points;
    /* String variable for deck */
    private static String deckString = "AS 2S 3S 4S 5S 6S 7S 8S 9S TS JS QS KS AH 2H 3H 4H 5H 6H 7H 8H 9H TH JH QH KH AC 2C 3C 4C 5C 6C 7C 8C 9C TC JC QC KC AD 1D 2D 3D 4D 5D 6D 7D 8D 9D TD JD QD KD";
    /* ArrayList storage for shuffled deck */
    ArrayList<String> randDeck = new ArrayList<String>(52);

    /* Bridge class constructor */
    public Bridge() {
    }

    /**
     * shuffle method
     * read the deck string to a new list and randomly copy to a new list
     */
    public void shuffle() {
        String split[] = deckString.split(" ");
        List<String> decky = Arrays.asList(split);
        ArrayList<String> deck = new ArrayList<String>(decky);

        for (int n = 0; n < 53; n++) {
            randDeck.add(n, "0");
        }
        int total = 52;
        int pos;
        for (int i = 0; i < 52; i++) {
            pos = ((int) (Math.random() * total));
            randDeck.set(i, (deck.get(pos)));
            deck.remove(pos);
            total--;
        }
    }

    /**
     * deal method
     * deal 13 cards to each player
     */
    public void deal() {
        for (int i = 0; i < randDeck.size() - 1; i += 4) {
            p1 += randDeck.get(i);
            p2 += randDeck.get(i + 1);
            p3 += randDeck.get(i + 2);
            p4 += randDeck.get(i + 3);
        }
    }

    /**
     * getPoints method
     * calculate points based on player deck string parameter
     */
    public int getPoints(String player) {
        points = 0;
        int countS = 0, countD = 0, countC = 0, countH = 0;
        boolean singleton = false;
        boolean doubleton = false;
        for (int i = 0; i < player.length(); i++) {
            if (player.charAt(i) == 'A')
                points += 4;
            else if (player.charAt(i) == 'K')
                points += 3;
            else if (player.charAt(i) == 'Q')
                points += 2;
            else if (player.charAt(i) == 'J')
                points++;
            if (player.charAt(i) == 'S')
                countS++;
            else if (player.charAt(i) == 'D')
                countD++;
            else if (player.charAt(i) == 'C')
                countC++;
            else if (player.charAt(i) == 'H')
                countH++;
        }
        if (countS == 0)
            points += 3;
        else if (countS == 1)
            singleton = true;
        else if (countS == 2)
            doubleton = true;
        if (countD == 0)
            points += 3;
        else if (countD == 1)
            singleton = true;
        else if (countD == 2)
            doubleton = true;
        if (countC == 0)
            points += 3;
        else if (countC == 1)
            singleton = true;
        else if (countC == 2)
            doubleton = true;
        if (countH == 0)
            points += 3;
        else if (countH == 1)
            singleton = true;
        else if (countH == 2)
            doubleton = true;
        if (singleton)
            points += 2;
        if (doubleton)
            points++;
        return points;
    }

    /**
     * printPlayer method
     * print the deck and points of a player (insert spaces in the deck)
     */
    public void printPlayer(String player, int pNum) {
        String playerPrint = "";
        for (int i = 0; i < player.length() - 1; i += 2) {
            playerPrint += player.substring(i, i + 2);
            playerPrint += " ";
        }
        System.out.println("Player " + pNum);
        System.out.println("Cards: " + playerPrint);
        int playerPoints = getPoints(player);
        System.out.println("Points: " + playerPoints + "\n");
        if(playerPoints > winnerPoints) {
            winnerPoints = playerPoints;
            winner = pNum;
        }
    }

    /**
     * declareWinner method
     * print the winner of the game by the number of points they scored
     */
    public void declareWinner() {
        System.out.println("The winner is Player " + winner);
        System.out.println("They have " + winnerPoints + " points.");
    }
}