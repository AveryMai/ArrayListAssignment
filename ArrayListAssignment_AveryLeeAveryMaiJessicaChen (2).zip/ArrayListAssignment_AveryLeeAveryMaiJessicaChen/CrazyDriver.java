/**
 * Teacher: Ms. Krasteva
 * Assignment: This program creates a random sentence with words from a word
 * bank made from arrayList.
 * calculates weighted averages
 * 
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/07/2023
 */

public class CrazyDriver extends CrazySentences {

    /**
     * Main method of the assignment
     * Calls methods from CrazySentences class
     */
    public static void main(String[] args) {
        CrazySentences s1 = new CrazySentences();
        CrazySentences s2 = new CrazySentences();
        CrazySentences s3 = new CrazySentences();
        CrazySentences s4 = new CrazySentences();
        CrazySentences s5 = new CrazySentences();

        s1.fillArray();
        s1.printSentence();

        s2.fillArray();
        s2.printSentence();

        s3.fillArray();
        s3.printSentence();

        s4.fillArray();
        s4.printSentence();

        s5.fillArray();
        s5.printSentence();
    }
}