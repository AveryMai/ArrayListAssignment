/**
 * Teacher: Ms. Krasteva
 * Assignment: This program creates a poem with randomized words from an original poem stored in word banks made with ArrayLists
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/07/2023
 */

/* imports the ArrayList class */
import java.util.*;

public class AiPoem {

    /**
     * Start of the program
     * String variables to alter using random generator
     */
    private String sentence1 = "";
    private String sentence2 = "";
    private String sentence3 = "";
    private String sentence4 = "";

    /**
     * word storage for the random sentence; words are called to be stored in
     * ArrayLists based on their type (e.g. verb, noun, etc.)
     */
    ArrayList<String> firstWord = new ArrayList<String>();
    ArrayList<String> noun = new ArrayList<String>();
    ArrayList<String> verb = new ArrayList<String>();
    ArrayList<String> preposition = new ArrayList<String>();
    ArrayList<String> article = new ArrayList<String>();
    ArrayList<String> adjective = new ArrayList<String>();
    ArrayList<String> adverb = new ArrayList<String>();
    ArrayList<String> conjunction = new ArrayList<String>();

    /* AiPoem class constructor */
    public AiPoem() {
    }

    /**
     * fillArray method
     * calls the fill methods to fill the ArrayLists with the words from the poem
     */
    public void fillArray() {
        fillFirstWord();
        fillNoun();
        fillVerb();
        fillPreposition();
        fillArticle();
        fillAdjective();
        fillAdverb();
        fillConjunction();
    }

    /**
     * fillPronoun method
     * word bank containing the first words used throughout the existing poem
     * includes the pronoun "he" and noun "Robin"
     */
    public void fillFirstWord() {
        firstWord.add("He");
        firstWord.add("Robin");
    }

    /**
     * fillNoun method
     * word bank containing the nouns used throughout the existing poem
     */
    public void fillNoun() {
        noun.add("frog");
        noun.add("table");
        noun.add("orange");
        noun.add("porridge");
    }

    /**
     * fillVerb method
     * word bank containing the verbs used throughout the existing poem
     */
    public void fillVerb() {
        verb.add("sees");
        verb.add("sits");
        verb.add("croaks");
        verb.add("jumps");
        verb.add("laughs");
        verb.add("spills");
    }

    /**
     * fillPreposition method
     * word bank containing the prepositions used throughout the existing poem
     */
    public void fillPreposition() {
        preposition.add("on");
        preposition.add("beside");
    }

    /**
     * fillArticle method
     * word bank containing the articles used throughout the existing poem
     */
    public void fillArticle() {
        article.add("a");
        article.add("the");
    }

    /**
     * fillAdjective method
     * word bank containing the adjectives used throughout the existing poem
     */
    public void fillAdjective() {
        adjective.add("green");
        adjective.add("round");
        adjective.add("hot");
    }

    /**
     * fillAdverb method
     * word bank containing the adverbs used throughout the existing poem
     */
    public void fillAdverb() {
        adverb.add("rapidly");
        adverb.add("peacefully");
    }

    /**
     * fillConjunction method
     * word bank containing the conjunction used throughout the existing poem
     */
    public void fillConjunction() {
        conjunction.add("and");
    }

    /**
     * makePoem method
     * assembles four sentences word by word using generator to access ArrayLists
     */
    public void makePoem() {
        // generates the first sentence with randomized verbs, articles, adjectives,
        // nouns, and prepositions
        sentence1 += firstWord.get((int) (Math.random() * firstWord.size()));
        sentence1 += " ";
        sentence1 += verb.get((int) (Math.random() * verb.size()));
        sentence1 += " ";
        sentence1 += article.get((int) (Math.random() * article.size()));
        sentence1 += " ";
        sentence1 += adjective.get((int) (Math.random() * adjective.size()));
        sentence1 += " ";
        sentence1 += noun.get((int) (Math.random() * noun.size()));
        sentence1 += " ";
        sentence1 += preposition.get((int) (Math.random() * preposition.size()));
        sentence1 += " ";
        sentence1 += article.get((int) (Math.random() * article.size()));
        sentence1 += " ";
        sentence1 += noun.get((int) (Math.random() * noun.size()));
        sentence1 += ",";
        // generates the second sentence with randomized verbs, articles, adjectives,
        // nouns, and prepositions
        sentence2 += firstWord.get((int) (Math.random() * firstWord.size()));
        sentence2 += " ";
        sentence2 += verb.get((int) (Math.random() * verb.size()));
        sentence2 += " ";
        sentence2 += adverb.get((int) (Math.random() * adverb.size()));
        sentence2 += " ";
        sentence2 += preposition.get((int) (Math.random() * preposition.size()));
        sentence2 += " ";
        sentence2 += article.get((int) (Math.random() * article.size()));
        sentence2 += " ";
        sentence2 += adjective.get((int) (Math.random() * adjective.size()));
        sentence2 += " ";
        sentence2 += noun.get((int) (Math.random() * noun.size()));
        sentence2 += ".";
        // generates the third sentence with randomized verbs, articles, adjectives,
        // nouns, and prepositions
        sentence3 += firstWord.get((int) (Math.random() * firstWord.size()));
        sentence3 += " ";
        sentence3 += verb.get((int) (Math.random() * verb.size()));
        sentence3 += " ";
        sentence3 += conjunction.get((int) (Math.random() * conjunction.size()));
        sentence3 += " ";
        sentence3 += verb.get((int) (Math.random() * verb.size()));
        sentence3 += " ";
        sentence3 += adverb.get((int) (Math.random() * adverb.size()));
        sentence3 += ",";
        // generates the fourth sentence with randomized verbs, articles, adjectives,
        // nouns, and prepositions
        sentence4 += firstWord.get((int) (Math.random() * firstWord.size()));
        sentence4 += " ";
        sentence4 += verb.get((int) (Math.random() * verb.size()));
        sentence4 += " ";
        sentence4 += conjunction.get((int) (Math.random() * conjunction.size()));
        sentence4 += " ";
        sentence4 += verb.get((int) (Math.random() * verb.size()));
        sentence4 += " ";
        sentence4 += article.get((int) (Math.random() * article.size()));
        sentence4 += " ";
        sentence4 += adjective.get((int) (Math.random() * adjective.size()));
        sentence4 += " ";
        sentence4 += noun.get((int) (Math.random() * noun.size()));
        sentence4 += ".";
    }

    /**
     * printPoem method
     * Calls makePoem to generate a new sentences
     * Prints the new sentences generated
     */
    public void printPoem() {
        makePoem();
        System.out.println(sentence1);
        System.out.println(sentence2);
        System.out.println(sentence3);
        System.out.println(sentence4);
    }
}
