/**
 * Teacher: Ms. Krasteva
 * Assignment: This program is the driver class to the Ai Poem class
 * It creates a poem with randomized words from an original poem stored in wordbanks made with ArrayLists
 * @author Avery Mai, Avery Lee, Jessica Chen
 * @version 03/07/2023
 */

public class AiDriver extends AiPoem {

    /**
     * Main method of the assignment
     * Creates new object "p"
     * Calls methods from AiPoem class
     */
      public static void main(String[] args){
        AiPoem p = new AiPoem();
        p.fillArray();
        p.printPoem();
    }
}